
PROJECT_ID               = "myproject32549"
PROJECT_NUM              = "683169793466"
LOCATION                 = "us-central1"

REGION                   = "us-central1"
BQ_LOCATION              = "US"
VPC_NETWORK_NAME         = "ucaip-haystack-vpc-network"

VERTEX_SA                = "683169793466-compute@developer.gserviceaccount.com"

PREFIX                   = "ndr-v1"
VERSION                  = "v1"

APP                      = "sp"
MODEL_TYPE               = "2tower"
FRAMEWORK                = "tfrs"
DATA_VERSION             = "v1"
TRACK_HISTORY            = "5"

BUCKET_NAME              = "ndr-v1-myproject32549-bucket"
BUCKET_URI               = "gs://ndr-v1-myproject32549-bucket"
SOURCE_BUCKET            = "spotify-million-playlist-dataset"

DATA_GCS_PREFIX          = "data"
DATA_PATH                = "gs://ndr-v1-myproject32549-bucket/data"
VOCAB_SUBDIR             = "vocabs"
VOCAB_FILENAME           = "vocab_dict.pkl"

CANDIDATE_PREFIX         = "candidates"
TRAIN_DIR_PREFIX         = "train"
VALID_DIR_PREFIX         = "valid"

VPC_NETWORK_FULL         = "projects/683169793466/global/networks/ucaip-haystack-vpc-network"

BQ_DATASET               = "spotify_e2e_test"
BQ_TABLE_TRAIN           = "train_flatten_last_5"
BQ_TABLE_VALID           = "train_flatten_valid_last_5"
BQ_TABLE_CANDIDATES      = "candidates"

REPO_SRC                 = "src"
PIPELINES_SUB_DIR        = "feature_pipes"

REPOSITORY               = "ndr-v1-spotify"
IMAGE_NAME               = "train-v1"
REMOTE_IMAGE_NAME        = "us-central1-docker.pkg.dev/myproject32549/ndr-v1-spotify/train-v1"
DOCKERNAME               = "tfrs"

SERVING_IMAGE_URI_CPU    = "us-docker.pkg.dev/vertex-ai/prediction/tf2-cpu.2-11:latest"
SERVING_IMAGE_URI_GPU    = "us-docker.pkg.dev/vertex-ai/prediction/tf2-gpu.2-11:latest"

